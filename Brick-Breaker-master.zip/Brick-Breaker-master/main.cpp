#include "game.h"
#include <iostream>
#include "collidable.h"
using namespace std;


int main()
{



	//Create an object of controller
	game Game;

	Game.go();


	return 0;
	//gitest
	//allam was here
}

